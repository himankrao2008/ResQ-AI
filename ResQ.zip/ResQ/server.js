// RESQ backend. Zero dependencies (Node 18+). Run: node server.js
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
try { fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n').forEach(l => { const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2]; }); } catch {}
const PORT = process.env.PORT || 3000, DBF = path.join(__dirname, 'data.json');
const KEY = process.env.ANTHROPIC_API_KEY, MODEL = process.env.AI_MODEL || 'claude-sonnet-4-5';
const HELPLINE = process.env.EMERGENCY_NUMBER || '112';
const STAGES = ['received', 'assessed', 'prioritized', 'matching', 'assigned', 'dispatched', 'in_progress', 'resolved'];
const hash = p => crypto.scryptSync(p, 'resq-demo-salt', 32).toString('hex');
const C = [17.385, 78.4867], now = () => new Date().toISOString(), uid = () => crypto.randomBytes(8).toString('hex');

function seed() {
  const R = (id, name, type, dy, dx) => ({ id, name, type, available: true, simulated: true, lat: C[0] + dy, lng: C[1] + dx });
  return {
    users: [
      { id: 'u1', name: 'Asha Rao', email: 'user@resq.demo', phone: '+91 90000 00001', role: 'user', pw: hash('demo123'), info: 'Blood group O+, no known allergies' },
      { id: 'a1', name: 'Coordinator Mehta', email: 'admin@resq.demo', phone: '', role: 'admin', pw: hash('admin123'), info: '' }],
    contacts: [{ id: 'c1', userId: 'u1', name: 'Ravi Rao', phone: '+91 90000 00002', relation: 'Brother' }],
    resources: [
      R('r1', 'Water Rescue Team Alpha', 'boat', .03, .02), R('r2', 'Water Rescue Team Bravo', 'boat', -.04, .03),
      R('r3', 'Fire Unit 7', 'fire', .02, -.03), R('r4', 'Fire Unit 9', 'fire', -.02, -.04),
      R('r5', 'Ambulance A1', 'ambulance', .015, .01), R('r6', 'Ambulance A2', 'ambulance', -.025, -.015), R('r7', 'Ambulance A3', 'ambulance', .04, -.02),
      R('r8', 'Search and Rescue Team 1', 'usar', .05, .04), R('r9', 'Water Station W1', 'water', .01, .03),
      R('r10', 'Food Distribution Center F1', 'food', -.01, -.03), R('r11', 'Shelter S1', 'shelter', .03, -.01), R('r12', 'Medical Supply Depot M1', 'medsupply', -.03, .02)],
    incidents: [], notifications: [], audit: [], seq: 0
  };
}
let db; try { db = JSON.parse(fs.readFileSync(DBF, 'utf8')); } catch { db = seed(); }
const save = () => fs.writeFileSync(DBF, JSON.stringify(db, null, 1));
const sessions = {};

const LABEL = { boat: 'Water rescue team', fire: 'Fire and emergency unit', usar: 'Search and rescue team', ambulance: 'Ambulance', water: 'Drinking water supplies', food: 'Emergency food supplies', shelter: 'Temporary shelter', medsupply: 'Medical supplies' };

// ---------- Rule-based assessment (instant; LLM only enriches afterwards, never blocks) ----------
function assess(i) {
  let s = 0; const why = [], t = i.type, n = +i.people || 1;
  if (['Fire', 'Building Collapse', 'Earthquake'].includes(t)) { s += 3; why.push(`${t} carries direct risk to life`); }
  if (['Flood', 'Landslide', 'Cyclone or Storm'].includes(t)) { s += 1; why.push(`${t} hazards can escalate quickly`); }
  if (i.trapped) { s += 3; why.push('people are trapped'); }
  if (i.injured) { s += 2; why.push('injuries are reported'); }
  if (i.worsening) { s += 2; why.push('the situation is getting worse'); }
  const vul = [i.children && 'children', i.elderly && 'elderly people', i.disabled && 'people needing special assistance'].filter(Boolean);
  if (vul.length) { s += 1; why.push('vulnerable people present: ' + vul.join(', ')); }
  if (n >= 5) { s += 1; why.push(`${n} people affected`); }
  if (/bleed|unconscious|not breathing|can.?t breathe|chest pain|drown|stroke|seizure/i.test(i.description || '')) { s += 3; why.push('description mentions a life-threatening symptom'); }
  if (t === 'Medical Emergency' && s < 4) { s = 4; why.push('medical emergencies default to at least HIGH'); }
  const priority = s >= 6 ? 'CRITICAL' : s >= 4 ? 'HIGH' : s >= 2 ? 'MODERATE' : 'LOW';
  const lv = a => priority === 'CRITICAL' ? a : priority === 'HIGH' ? (a === 'Critical' ? 'High' : a) : 'Moderate';
  const need = [], add = (type, level) => need.push({ type, label: LABEL[type], level });
  if (['Flood', 'Trapped or Stranded', 'Cyclone or Storm'].includes(t)) add('boat', 'Critical');
  if (t === 'Fire') add('fire', 'Critical');
  if (['Earthquake', 'Building Collapse', 'Landslide'].includes(t) || (i.trapped && !need.length)) add('usar', 'Critical');
  if (i.injured || ['Medical Emergency', 'Road Accident'].includes(t)) add('ambulance', t === 'Medical Emergency' || i.injured ? 'High' : 'Moderate');
  const nd = i.needs || [];
  if (nd.includes('Drinking water')) add('water', 'High'); if (nd.includes('Food')) add('food', 'Moderate');
  if (nd.includes('Temporary shelter')) add('shelter', 'Moderate');
  if (['Medicines', 'First aid'].some(x => nd.includes(x))) add('medsupply', 'Moderate');
  if (!need.length) add('usar', 'Moderate');
  need.forEach(x => x.level = x.level === 'Critical' && priority !== 'CRITICAL' ? 'High' : x.level);
  const summary = `${n} ${n === 1 ? 'person is' : 'people are'} affected by a ${t.toLowerCase()} situation${i.trapped ? ', with people trapped' : ''}. ${i.injured ? 'Injuries are reported. ' : ''}${vul.length ? 'Vulnerable individuals (' + vul.join(', ') + ') need special consideration. ' : ''}Recommended: ${need.map(x => x.label.toLowerCase()).join(', ')}.`;
  return { priority, score: s, reasons: why, needs: need, summary, source: 'rule-based', at: now() };
}
async function enrich(i) {
  if (!KEY) return;
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: MODEL, max_tokens: 400, system: 'You assist emergency coordinators. Write a concise, factual 2-3 sentence situation assessment and one sentence explaining the priority. Never promise rescue or response times.', messages: [{ role: 'user', content: JSON.stringify({ report: i.report, computed_priority: i.assessment.priority, reasons: i.assessment.reasons }) }] }) });
    const d = await r.json(), t = d.content && d.content[0] && d.content[0].text;
    if (t) { i.assessment.summary = t; i.assessment.source = 'AI (' + MODEL + ') + rules'; log(i, 'AI assessment enriched by LLM provider'); save(); }
  } catch (e) { console.log('LLM fallback in use:', e.message); }
}
function log(i, msg, who = 'system') { db.audit.push({ id: uid(), incident: i.id, who, msg, t: now() }); }
function ev(i, stage, msg, sim = true) { i.timeline.push({ stage, msg, t: now(), simulated: sim }); i.status = stage; i.updated = now(); }

function create(b, user) {
  const id = 'RSQ-2026-' + String(++db.seq).padStart(3, '0'), a = ['type', 'people', 'injured', 'children', 'elderly', 'disabled', 'trapped', 'worsening', 'description', 'needs', 'lat', 'lng', 'landmark', 'address'];
  const report = {}; a.forEach(k => report[k] = b[k]);
  report.people = Math.max(1, Math.min(10000, +b.people || 1)); report.needs = Array.isArray(b.needs) ? b.needs.slice(0, 12) : [];
  const i = { id, key: uid(), userId: user ? user.id : null, demo: !!b.demo, report, ...report, created: now(), updated: now(), timeline: [], messages: [], assignments: [], notifications: [] };
  ev(i, 'received', 'SOS received by RESQ', false);
  i.assessment = assess(report); i.priority = i.assessment.priority;
  ev(i, 'assessed', 'AI assessment completed (' + i.assessment.source + ')', false);
  ev(i, 'prioritized', 'Request prioritized as ' + i.priority, false);
  ev(i, 'matching', 'Resource matching in progress (simulated resource pool)');
  i.messages.push({ from: 'RESQ', text: 'Your request was received. This is a coordination platform and does not replace official services. If life is in immediate danger, call ' + HELPLINE + '.', t: now() });
  (db.contacts.filter(c => user && c.userId === user.id)).forEach(c => i.notifications.push({ to: c.name, phone: c.phone, text: `RESQ ${id}: ${report.type} reported near ${report.landmark || (report.lat + ',' + report.lng)}. Status: matching resources. Needs: ${report.needs.join(', ') || 'not specified'}.`, status: 'SIMULATED - not sent', t: now() }));
  db.incidents.push(i); log(i, 'Incident created', user ? user.email : 'anonymous'); save(); enrich(i); return i;
}
const DEMOS = [
  { type: 'Flood', people: 6, injured: true, elderly: true, trapped: true, worsening: true, needs: ['Drinking water', 'Food', 'Temporary shelter'], description: 'Six people stranded on first floor, water rising. One person has a leg injury.', landmark: 'Riverside Apartments', dy: .006, dx: .004 },
  { type: 'Fire', people: 4, injured: true, trapped: true, worsening: true, needs: ['First aid'], description: 'Fire on second floor, four people inside, one burned.', landmark: 'Market Street Building 12', dy: -.008, dx: .007 },
  { type: 'Medical Emergency', people: 1, injured: false, needs: ['Medical evacuation'], description: 'Adult with chest pain, conscious but weak.', landmark: 'Lake View Colony', dy: .01, dx: -.006 },
  { type: 'Earthquake', people: 12, injured: true, trapped: true, children: true, worsening: true, needs: ['Rescue equipment', 'First aid', 'Temporary shelter'], description: 'Partial collapse, two people trapped under debris.', landmark: 'Old Town Sector 4', dy: -.012, dx: -.01 }];

// ---------- HTTP ----------
const send = (res, code, o) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
const pub = (i, full) => { const { key, ...r } = i; return full ? i : r; };
const body = req => new Promise(r => { let d = ''; req.on('data', c => { d += c; if (d.length > 2e6) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(d || '{}')); } catch { r({}); } }); });
const can = (i, u, k) => (u && u.role === 'admin') || (u && i.userId === u.id) || (k && k === i.key);

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x'), p = url.pathname, m = req.method;
  if (!p.startsWith('/api/')) { res.writeHead(200, { 'content-type': 'text/html' }); return res.end(fs.readFileSync(path.join(__dirname, 'index.html'))); }
  const tok = (req.headers.authorization || '').replace('Bearer ', ''), user = db.users.find(u => u.id === sessions[tok]);
  const admin = user && user.role === 'admin', b = m === 'GET' ? {} : await body(req);
  try {
    if (p === '/api/config') return send(res, 200, { helpline: HELPLINE, ai: KEY ? 'LLM + rules' : 'rule-based fallback', model: KEY ? MODEL : null });
    if (p === '/api/login' && m === 'POST') {
      const u = db.users.find(x => x.email === (b.email || '').toLowerCase() && x.pw === hash(b.password || ''));
      if (!u) return send(res, 401, { error: 'Incorrect email or password' });
      const t = uid(); sessions[t] = u.id; return send(res, 200, { token: t, user: { id: u.id, name: u.name, role: u.role, email: u.email } });
    }
    if (p === '/api/me' && m === 'GET') return user ? send(res, 200, { id: user.id, name: user.name, role: user.role, email: user.email, phone: user.phone, info: user.info }) : send(res, 401, { error: 'Not signed in' });
    if (p === '/api/me' && m === 'PATCH' && user) { Object.assign(user, { name: b.name || user.name, phone: b.phone ?? user.phone, info: b.info ?? user.info }); save(); return send(res, 200, { ok: true }); }
    if (p === '/api/sos' && m === 'POST') { if (!b.type) return send(res, 400, { error: 'Emergency type required' }); const i = create(b, user); return send(res, 201, { id: i.id, key: i.key, priority: i.priority }); }
    if (p === '/api/contacts') {
      if (!user) return send(res, 401, { error: 'Sign in required' });
      if (m === 'POST') { if (!b.name || !b.phone) return send(res, 400, { error: 'Name and phone required' }); db.contacts.push({ id: uid(), userId: user.id, name: b.name, phone: b.phone, relation: b.relation || '' }); save(); }
      if (m === 'DELETE') { db.contacts = db.contacts.filter(c => !(c.id === b.id && c.userId === user.id)); save(); }
      return send(res, 200, db.contacts.filter(c => c.userId === user.id));
    }
    if (p === '/api/incidents' && m === 'GET') {
      if (!user) return send(res, 401, { error: 'Sign in required' });
      return send(res, 200, db.incidents.filter(i => admin || i.userId === user.id).map(i => pub(i)).reverse());
    }
    let mt = p.match(/^\/api\/incidents\/([\w-]+)$/);
    if (mt) {
      const i = db.incidents.find(x => x.id === mt[1]); if (!i) return send(res, 404, { error: 'Not found' });
      if (!can(i, user, url.searchParams.get('key'))) return send(res, 403, { error: 'Not authorized' });
      if (m === 'GET') return send(res, 200, { ...pub(i), resources: db.resources.filter(r => i.assignments.some(a => a.id === r.id)), audit: admin ? db.audit.filter(a => a.incident === i.id) : undefined });
      if (!admin) return send(res, 403, { error: 'Administrator access required' });
      if (b.priority && b.priority !== i.priority) { log(i, `Priority changed ${i.priority} -> ${b.priority}` + (b.reason ? ' (' + b.reason + ')' : ''), user.email); i.priority = b.priority; ev(i, i.status, 'Priority updated to ' + b.priority, false); }
      if (b.assign) {
        const r = db.resources.find(x => x.id === b.assign);
        if (!r || !r.available) return send(res, 409, { error: 'Resource unavailable' });
        r.available = false; i.assignments.push({ id: r.id, name: r.name, type: r.type, t: now() }); log(i, 'Assigned ' + r.name + ' (simulated)', user.email);
        if (STAGES.indexOf(i.status) < 4) ev(i, 'assigned', r.name + ' assigned (simulated demonstration)'); else i.timeline.push({ stage: i.status, msg: r.name + ' assigned (simulated)', t: now(), simulated: true });
      }
      if (b.status && STAGES.includes(b.status) && b.status !== i.status) {
        ev(i, b.status, 'Status set to ' + b.status.replace('_', ' ') + ' by coordinator (demonstration update)'); log(i, 'Status -> ' + b.status, user.email);
        if (b.status === 'resolved') { i.assignments.forEach(a => { const r = db.resources.find(x => x.id === a.id); if (r) r.available = true; }); i.resolved = now(); }
      }
      if (b.note) { i.messages.push({ from: 'Response coordinator (simulated)', text: String(b.note).slice(0, 500), t: now() }); log(i, 'Note: ' + b.note, user.email); }
      i.updated = now(); save(); return send(res, 200, { ok: true });
    }
    if (p === '/api/resources') {
      if (!admin) return send(res, 403, { error: 'Administrator access required' });
      if (m === 'PATCH') { const r = db.resources.find(x => x.id === b.id); if (r) { r.available = !!b.available; save(); } }
      return send(res, 200, db.resources);
    }
    if (p === '/api/demo' && m === 'POST') {
      if (b.reset) { if (!admin) return send(res, 403, { error: 'Administrator access required' }); db = seed(); save(); return send(res, 200, { ok: true }); }
      const d = DEMOS[(+b.case || 1) - 1]; if (!d) return send(res, 400, { error: 'Unknown case' });
      const i = create({ ...d, lat: C[0] + d.dy, lng: C[1] + d.dx, demo: true }, user); return send(res, 201, { id: i.id, key: i.key });
    }
    send(res, 404, { error: 'Unknown endpoint' });
  } catch (e) { console.error(e); send(res, 500, { error: 'Server error' }); }
}).listen(PORT, () => console.log(`RESQ running at http://localhost:${PORT}  |  AI: ${KEY ? 'LLM (' + MODEL + ')' : 'rule-based fallback'}`));
