# RESQ - AI-Assisted Disaster Response and Coordination (prototype)

## Run
    node server.js        # Node 18+ (no npm install needed)
    open http://localhost:3000
Copy `.env.example` to `.env` to configure. Data persists in `data.json` (delete it to reset, or use Reset in the dashboard).

## Demo logins
- User: user@resq.demo / demo123
- Coordinator: admin@resq.demo / admin123

## Demo walkthrough
1. Home > SOS > complete 5 steps > Submit. You land on the tracking page (polls every 5s).
2. Sign in as coordinator in another tab > open the incident > assign resources, change status, send a note.
3. Tracking page updates. Mark resolved; it moves to the user's history (sign in as user to see it).
4. Dashboard "Case 01-04" buttons create ready-made flood, fire, medical and earthquake incidents.

## AI provider
Set `ANTHROPIC_API_KEY` in `.env`. The key stays on the server. SOS submission and the rule-based assessment are instant; the LLM only rewrites the summary afterwards. Without a key, the rule engine (`assess()` in server.js) is used.

## Maps
Leaflet + OpenStreetMap tiles (no key). Needs internet in the browser; without it, coordinates and lists still work.

## API reference
POST /api/login | GET /api/me | PATCH /api/me | GET /api/config
POST /api/sos (anonymous allowed; returns id + tracking key)
GET /api/incidents (own, or all for admin) | GET /api/incidents/:id?key= | PATCH /api/incidents/:id (admin: priority, status, assign, note)
GET|PATCH /api/resources (admin) | GET|POST|DELETE /api/contacts | POST /api/demo {case:1-4} or {reset:true}

## Safety
All dispatch, resource positions, team assignments and contact notifications are SIMULATED and labelled so. Nothing is sent to real services. 112 is shown throughout and is configurable.
